# SENG201-Project

All of our files, including metadata and .project file are in our zip. 
1) Ensure Eclipse in installed on the machine
2) Open eclipse, go to File, open project from filesystem, and then select SENG-201-Project
3) Run Game.java

1) Ensure Java 11 is installed on the machine
2) Open the zip folder in a terminal window
3) Run "java -jar dfg21_smc472_basicFarmingSimulator.jar"
