package main;

public interface searchable {
	boolean search();
}
